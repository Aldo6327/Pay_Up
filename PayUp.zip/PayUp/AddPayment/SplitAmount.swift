//
//  SplitAmount.swift
//  PayUp
//
//  Created by Aldo Ayala on 11/19/17.
//  Copyright © 2017 Aldo Ayala. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth


class SplitAmount: UIViewController {
    
    // User Info Passed in from LoginVC
    var userData: UserInfo!
    
    @IBOutlet weak var userInfoUID: UILabel!
    
    @IBOutlet weak var userInfoEmail: UILabel!
    
    
    let currentUserEmail = Auth.auth().currentUser?.email
    var userEmailArray: [String] = []

    @IBOutlet weak var paymentDesc: UITextField!
    var transactionHistory: Transactions!
    @IBOutlet weak var finalAmount: UILabel!
    @IBOutlet weak var price: UITextField!
    @IBOutlet weak var TotalPeople: UITextField!
    let refTransaction = Database.database().reference(withPath: "Transactions")
    let currentUserUid = Auth.auth().currentUser?.uid
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userInfoUID.text = userData.uid
        userInfoEmail.text = userData.email
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func splitWithUserInput(amount: UITextField, splitby: UITextField) -> Float {
        let userPrice = price.text 
        let priceFloat = Float(userPrice!)
        let timestamp =  NSDate().timeIntervalSinceReferenceDate
        let usersTosplit = TotalPeople.text
        let users = Float(usersTosplit!)
        let userDesc = paymentDesc.text
        userEmailArray.append(currentUserEmail!)
        let newListedItemRef = self.refTransaction.child((userDesc?.lowercased())!)
        let newTransaction = Transactions(creator: currentUserEmail!, initialPayment: priceFloat!, splitAmount: priceFloat!/users!, description: userDesc, users: userEmailArray, timestamp: timestamp)
        newListedItemRef.setValue(newTransaction.toAnyObject())
        print(priceFloat as Any)
        return priceFloat! / users!
    }
        @IBAction func splitEvenly(_ sender: Any) {
          var money = self.splitWithUserInput(amount: price, splitby: TotalPeople)
           
            
           let thefinalAmount = String(money)
           finalAmount.text = thefinalAmount
            
            TotalPeople.resignFirstResponder()
            price.text = ""
            TotalPeople.text = ""
            paymentDesc.text = ""
            userEmailArray = []
            
    }

    @IBAction func addFriends(_ sender: Any) {
        let alert = UIAlertController(title: "Add Friends Email",
                                      message: "Add Friends To Split",
                                      preferredStyle: .alert)
        
        
        alert.addTextField { (textField: UITextField) in
            textField.keyboardAppearance = .dark
            textField.keyboardType = .emailAddress
            textField.autocorrectionType = .default
            textField.placeholder = "Friend Email"
            textField.textColor = UIColor.black
            textField.font = UIFont(name: "Helvetica", size: 18)
        }
        let cancelAction = UIAlertAction(title: "Cancel",
                                         style: .default)
        
        let saveAction = UIAlertAction(title: "Add",
                                       style: .default) { action in
                                        guard let textField0 = alert.textFields?[0],
                                            var emailOfNewUser = textField0.text else { return }
                                        self.userEmailArray.append(emailOfNewUser)
                                        
    }
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion: nil)
    }
    @IBAction func signoutButton(_ sender: AnyObject) {
        do {
            try Auth.auth().signOut()
            dismiss(animated: true, completion: nil)
        } catch {
            
        }
    }
}
